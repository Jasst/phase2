# -*- coding: utf-8 -*-
"""Осознанный ответ: мысль из нескольких групп графа, рекуррентное
самосогласование, перепроверка и обучение на подтверждённом ответе.

Конвейер (всё, что трогает граф, выполняется в главном потоке):
  1. think():   несколько вариантов мысли — вся сеть и каждая релевантная
                группа нейронов. Каждый вариант рекуррентно уточняется:
                черновик снова подаётся в сеть, пока не стабилизируется.
  2. request(): LM пишет связный ответ по лучшей мысли.
  3. feed():    ответ проверяется сетью (support) и переписывается LM,
                лучшая версия сохраняется.
  4. final():   ответ, прошедший порог, обучает граф (train_words).
"""

import math
import os
import re
from dataclasses import dataclass

from mind import cosine

GROUPS = 3                    # сколько групп нейронов предлагают мысль
GROUP_WORDS = 2               # слов из каждой группы в затравку
RECUR_ROUNDS = 3              # шагов рекуррентного уточнения мысли
STABLE = 0.6                  # доля совпадения, при которой мысль считается устойчивой
LEARN_MIN = 0.12              # ниже этого оценки ответ не обучает граф
REVISE_ROUNDS = max(0, int(os.environ.get("BRAIN_REVISE", "1")))
W_SUPPORT, W_STAB, W_LEN = 0.5, 0.3, 0.2
# ИЗМ: support() в mind.py стал «косинус + покрытие» — его типичные значения
# выше, чем у чистого косинуса. Поднимаем порог, чтобы фильтр остался осмысленным.
# При новой метрике: слабый ответ ~0.07, средний ~0.30, хороший ~0.53.
# Порог 0.22 отсекает слабые и очень средние.
HINT_MIN_SUPPORT = float(os.environ.get("BRAIN_HINT_MIN", "0.22"))
# Приветствия и small talk не нуждаются в графе.
_GREET = re.compile(
    r"^\s*(привет|здравствуй\w*|добрый\s+(день|вечер|утро)|доброе\s+утро|хай|hi|hello)\b",
    re.I)

_WORD = re.compile(r"[^\W_]+")

_ANSWER_LABEL = re.compile(r"\bОТВЕТ\s*:\s*", re.I)
_ANSWER_LABEL_EN = re.compile(r"\bANSWER\s*:\s*", re.I)


def _split_rationale(text):
    """Делит текст на рациональ и финальный ответ по метке ОТВЕТ:/ANSWER:."""
    for pat in (_ANSWER_LABEL, _ANSWER_LABEL_EN):
        m = pat.search(text)
        if m:
            return text[:m.start()].strip(), text[m.end():].strip()
    return "", text.strip()

def tokens(text):
    return _WORD.findall(str(text).lower())


@dataclass
class Thought:
    words: list
    group: object          # id группы нейронов или None (вся сеть)
    stability: float
    support: float
    score: float

    def describe(self):
        where = "вся сеть" if self.group is None else f"группа {self.group}"
        return (f"мысль ({where}, оценка {self.score:.2f}): "
                + " ".join(self.words))


class Answerer:
    def __init__(self, brain, mind):
        self.brain = brain
        self.mind = mind

    def _ids(self, words):
        return [self.brain.words[w] for w in words if w in self.brain.words]

    # ---------- 1. мысль из нескольких групп ----------

    def _variants(self, seeds):
        """Варианты затравки: без группы и с словами каждой релевантной группы."""
        b = self.brain
        ctx = self.mind._context(seeds, b.adjacency())
        ranked = sorted(((cosine(ctx, cent), gid) for gid, cent in b.gcent.items() if cent),
                        reverse=True)
        out = [(None, [])]
        for sim, gid in ranked[:GROUPS]:
            if sim <= 0:
                break
            members = [w for w, g in b.wgroup.items() if g == gid and w not in seeds]
            members.sort(key=lambda w: -ctx.get(w, 0.0))
            extra = [w for w in members[:GROUP_WORDS] if ctx.get(w, 0.0) > 0]
            if extra:
                out.append((gid, extra))
        return out

    def _recur(self, seeds, words, target):
        """Уточнение: стабильное ядро сохраняется, хвост заменяется.

        ИЗМ: старая версия полностью заменяла current на nxt. Если слово
        подтверждалось на второй итерации, а потом выпадало — оно терялось
        безвозвратно. Теперь слова, которые есть и в текущем, и в следующем
        черновике, образуют ядро; хвост подстраивается под новое поколение.
        Мысль реально сходится, а не скачет между двумя состояниями.
        """
        current, stab = list(words), 0.0
        for _ in range(RECUR_ROUNDS):
            nxt, _ = self.mind.answer(self._ids(seeds + current[:4]), target)
            if not nxt:
                break
            a, c = set(nxt), set(current)
            stab = len(a & c) / max(1, len(a | c))
            stable_core = [w for w in current if w in a]
            new_extra = [w for w in nxt if w not in stable_core]
            current = (stable_core + new_extra)[:target] or nxt
            if stab >= STABLE:
                break
        return current, stab

    def think(self, question, target):
        """Лучшая мысль среди вариантов или None, если вопрос незнаком сети."""
        seeds = [w for w in tokens(question) if w in self.brain.words]
        if not seeds:
            return None, seeds
        best = None
        for gid, extra in self._variants(seeds):
            words, _ = self.mind.answer(self._ids(seeds + extra), target)
            if not words:
                continue
            words, stab = self._recur(seeds, words, target)
            support = self.mind.support(seeds, words)
            length = min(1.0, len(words) / max(1, target))
            score = W_SUPPORT * support + W_STAB * stab + W_LEN * length
            t = Thought(words, gid, stab, support, score)
            if best is None or t.score > best.score:
                best = t
        return best, seeds

    # ---------- 2–3. LM пишет и проверяется ----------

    def judge(self, seeds, text):
        """Насколько текст опирается на граф вопроса (0..1)."""
        return self.mind.support(seeds, tokens(text))

    def begin(self, question, target):
        if _GREET.match(str(question)):
            thought, seeds = None, []
        else:
            thought, seeds = self.think(question, target)
            if thought is not None and thought.support < HINT_MIN_SUPPORT:
                thought = None
        return {"q": question, "seeds": seeds, "thought": thought, "stage": 0,
                "best": None, "best_score": -1.0}

    def request(self, st):
        th = st["thought"]
        if st["stage"] == 0:
            note = ""
            if th is not None and th.words:
                where = "вся сеть" if th.group is None else f"группа {th.group}"
                note = (f"Мысль сети ({where}): связанные по смыслу слова — "
                        f"{' '.join(th.words)}. Опирайся на них, если они согласуются "
                        "с вопросом. Если нет — ответь по существу и не выдумывай.")
            q = (st["q"] + "\n\n"
                           "Сначала кратко (1–2 предложения) опиши ход мысли, "
                           "затем с новой строки напиши: ОТВЕТ: <твой ответ>")
            return q, note, True
        # ← НОВОЕ: ветка перепроверки
        prev = st["best"] or ""
        return (f"Вопрос: {st['q']}\nЧерновик ответа: {prev}\n"
                "Проверь черновик: верен ли он и отвечает ли на вопрос. Если да — "
                "повтори его. Если нет — дай исправленный ответ на русском, 1–3 предложения."
                ), "", False

    def feed(self, st, text):
        text = (text or "").strip()
        if text:
            rationale, answer = _split_rationale(text)
            st["rationale"] = rationale
            score = self.judge(st["seeds"], answer)
            if st["best"] is None or score >= st["best_score"]:
                st["best"], st["best_score"] = answer, score
        st["stage"] += 1
        return st["best"] is not None and st["stage"] <= REVISE_ROUNDS

    # ---------- 4. итог и обучение ----------

    def final(self, st):
        """(текст, оценка, from_lm) или None. Обучает граф, если оценка достаточна."""
        if st["best"] is not None:
            text, score, from_lm = st["best"], st["best_score"], True
            words = tokens(text)
        elif st["thought"] is not None:
            text = " ".join(st["thought"].words)
            score, from_lm = st["thought"].score, False
            words = st["thought"].words
        else:
            return None
        # Автообучения нет: непроверенный ответ (LM или граф) не закрепляется.
        # Закрепление только по явному /good или /teach (см. learn()).
        return text, score, from_lm

    def learn(self, question, words, confidence=1.0):
        q = tokens(question)
        self.brain.train_words(q + words, weight=confidence)  # ← weight
        self.brain._reinforce_answer(words, weight=confidence)

    def distill_rationale(self, st, confidence=1.0):
        """Дистиллирует ход мысли LM в граф, если он согласуется с вопросом."""
        rationale = st.get("rationale", "")
        if not rationale or not st["seeds"]:
            return
        rw = tokens(rationale)
        if not rw:
            return
        r_score = self.mind.support(st["seeds"], rw)
        if r_score < HINT_MIN_SUPPORT:
            return
        qw = tokens(st["q"])
        w = min(1.0, r_score * confidence)
        self.brain.train_words(qw + rw, weight=w)
        self.brain.adapt(qw + rw, confidence=w)

